<?php
　echo $_POST["filepond"];
?>
